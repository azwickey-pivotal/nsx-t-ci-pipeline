package io.pivotal.pcf.demo.fortuneuiboot;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

@Controller
public class BackendController {

    Logger LOG = LoggerFactory.getLogger(BackendController.class);

    @Value("${BACKEND:}")
    private String _backend;

    @RequestMapping(value = "/backend", method = RequestMethod.GET)
    @ResponseBody
    @CrossOrigin
    public ResponseEntity<String> backend() {
        LOG.info("Serving backend: " + _backend);
        if(StringUtils.isEmpty(_backend)) {
            return new ResponseEntity<String>(_backend,HttpStatus.NOT_FOUND);
        } else {
            return ResponseEntity.ok(_backend);
        }
    }
}
