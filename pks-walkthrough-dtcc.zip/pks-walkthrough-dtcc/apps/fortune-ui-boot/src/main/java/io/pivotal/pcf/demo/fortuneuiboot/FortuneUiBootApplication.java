package io.pivotal.pcf.demo.fortuneuiboot;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FortuneUiBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(FortuneUiBootApplication.class, args);
	}
}
