#!/usr/bin/env bash

docker build -t azwickey/fortune-ui-boot .
docker push azwickey/fortune-ui-boot:latest
